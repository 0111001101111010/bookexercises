#pragma once

#include <vector>

#include "Str.hpp"

std::vector<Str> split(const Str&);
