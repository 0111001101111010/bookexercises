#ifndef GUARD_urls_h
#define GUARD_urls_h

#include "Vec.h"
#include "Str.h"

Vec<Str> find_urls(const Str& s);

#endif
