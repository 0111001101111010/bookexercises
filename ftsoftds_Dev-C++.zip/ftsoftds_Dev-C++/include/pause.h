   char quit1359;  

   quit1359 = '\0';
   while (quit1359 != 'q')
   {
      cout << endl << "Press q to quit " << endl;
      cin >> quit1359;
   }

